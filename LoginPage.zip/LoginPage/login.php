<?php
$host = "your_mysql_host";
$username = "your_mysql_username";
$password = "your_mysql_password";
$database = "your_database_name";

$conn = new mysqli($host, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS $database");
$conn->query("USE $database");

// Create the users table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    dob DATE NOT NULL
)");

$action = $_POST['action'];

if ($action === 'login') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Implement secure password handling, for simplicity using plaintext in this example
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "Login successful!";
    } else {
        echo "Login failed. Invalid username or password.";
    }
} elseif ($action === 'register') {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $address = $_
