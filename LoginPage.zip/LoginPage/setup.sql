CREATE DATABASE IF NOT EXISTS your_database_name;
USE your_database_name;
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    dob DATE NOT NULL
);
INSERT INTO users (email, username, password, name, address, dob) VALUES 
    ('test@example.com', 'testuser', 'testpassword', 'Test User', 'Test Address', '1990-01-01');
