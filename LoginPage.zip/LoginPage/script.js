function toggleForms() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}

function login(event) {
    event.preventDefault();

    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const loginMessage = document.getElementById('loginMessage');

    // Assuming you have a server endpoint to handle the login process
    fetch('login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=login&username=${username}&password=${password}`,
    })
    .then(response => response.text())
    .then(data => {
        loginMessage.textContent = data;
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function register(event) {
    event.preventDefault();

    const email = document.getElementById('registerEmail').value;
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;
    const name = document.getElementById('registerName').value;
    const address = document.getElementById('registerAddress').value;
    const dob = document.getElementById('registerDOB').value;
    const loginMessage = document.getElementById('loginMessage');

    // Assuming you have a server endpoint to handle the registration process
    fetch('login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=register&email=${email}&username=${username}&password=${password}&name=${name}&address=${address}&dob=${dob}`,
    })
    .then(response => response.text())
    .then(data => {
        loginMessage.textContent = data;
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
